if (document.referrer.indexOf(window.location.host) == -1){ 
    document.getElementById("back").style.display = "none"
}